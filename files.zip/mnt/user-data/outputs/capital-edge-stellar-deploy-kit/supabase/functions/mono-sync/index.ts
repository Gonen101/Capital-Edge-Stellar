// mono-sync
//
// Pulls recent transactions for one connected bank account and hands them
// back shaped exactly like the app's existing CSV/Excel import already
// produces - { rawDate, desc, amount } with amount signed (positive = money
// in, negative = money out). The client then stages these through the
// exact same categorization-rule logic a file import already uses, so a
// live sync and a manual import behave identically from that point on -
// nothing about the accounting/categorization logic needed to change for
// this to work.
//
// Deploy with: supabase functions deploy mono-sync
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { connectionId } = await req.json();
    if (!connectionId) return json({ error: "Missing connectionId" }, 400);

    const monoSecretKey = Deno.env.get("MONO_SECRET_KEY");
    if (!monoSecretKey) return json({ error: "MONO_SECRET_KEY is not configured on this project" }, 500);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
    );
    const { data: { user }, error: userErr } = await supabase.auth.getUser();
    if (userErr || !user) return json({ error: "Not authenticated" }, 401);

    const { data: membership } = await supabase
      .from("company_members")
      .select("company_id, role")
      .eq("user_id", user.id)
      .limit(1)
      .maybeSingle();
    if (!membership) return json({ error: "No company found for this account" }, 404);
    if (membership.role === "viewer") return json({ error: "Your role doesn't allow syncing transactions" }, 403);

    // RLS on bank_connections already restricts this to the caller's own
    // company, but the explicit company_id check below makes that
    // intention obvious in the code too, not just implicit in the policy.
    const { data: connection, error: connErr } = await supabase
      .from("bank_connections")
      .select("*")
      .eq("id", connectionId)
      .eq("company_id", membership.company_id)
      .single();
    if (connErr || !connection) return json({ error: "Bank connection not found" }, 404);

    // Confirm the account's data is actually ready before asking for
    // transactions - a freshly-linked account can take a short while to
    // become available. See https://docs.mono.co/docs/financial-data/connect-link
    const statusRes = await fetch(`https://api.withmono.com/v2/accounts/${connection.external_account_id}`, {
      headers: { accept: "application/json", "mono-sec-key": monoSecretKey },
    });
    const statusBody = await statusRes.json();
    const dataStatus = statusBody?.data?.meta?.data_status || statusBody?.meta?.data_status;
    if (dataStatus === "UNAVAILABLE" || dataStatus === "FAILED") {
      return json({ error: "This bank hasn't made transaction data available yet - try again shortly, or reconnect the account." }, 409);
    }

    // Pull transactions, paginating until Mono stops returning full pages.
    // Documented at https://docs.mono.co/docs/quickstart
    let allTx: any[] = [];
    let page = 1;
    const maxPages = 20; // hard ceiling so a misbehaving response can't loop forever
    while (page <= maxPages) {
      const txRes = await fetch(`https://api.withmono.com/v2/accounts/${connection.external_account_id}/transactions?page=${page}`, {
        headers: { accept: "application/json", "mono-sec-key": monoSecretKey },
      });
      if (!txRes.ok) break;
      const txBody = await txRes.json();
      const rows = txBody?.data || [];
      allTx = allTx.concat(rows);
      if (rows.length === 0 || rows.length < 20) break; // short page = last page
      page++;
    }

    // IMPORTANT - verify this against your own account before trusting it:
    // some Mono endpoints return amounts in kobo (Nigeria's minor currency
    // unit, 100 kobo = ₦1), others in the major unit, and this can vary by
    // institution. Rather than guess based on the number's size (a real
    // ₦1,000+ transaction would be misread as kobo and divided by 100,
    // silently misstating it), this defaults to treating amounts as
    // already in the major unit. Make one small test transaction, sync it,
    // and compare - if everything shows 100x too large, set
    // AMOUNT_DIVISOR below to 100 and redeploy this function.
    const AMOUNT_DIVISOR = 1;

    const items = allTx.map((t) => {
      const amountRaw = Number(t.amount) || 0;
      const isDebit = String(t.type || "").toLowerCase() === "debit";
      const amountMajor = Math.abs(amountRaw) / AMOUNT_DIVISOR;
      return {
        rawDate: t.date || t.created_at || null,
        desc: t.narration || t.description || "Bank transaction",
        amount: isDebit ? -amountMajor : amountMajor,
        externalId: t.id || t._id || null,
      };
    }).filter((t) => t.rawDate && t.amount !== 0);

    await supabase.from("bank_connections").update({ last_synced_at: new Date().toISOString() }).eq("id", connectionId);

    return json({ items, institutionName: connection.institution_name });
  } catch (e) {
    return json({ error: String(e?.message || e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
