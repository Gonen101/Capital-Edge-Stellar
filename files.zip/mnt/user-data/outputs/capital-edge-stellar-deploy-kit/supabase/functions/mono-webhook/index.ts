// mono-webhook
//
// A public endpoint Mono's servers call directly (not your logged-in
// users), so it can't be protected by a user session the way the other two
// functions are. Instead, it's protected by a shared secret in the URL
// itself - configure the webhook URL in your Mono dashboard as:
//
//   https://YOUR_PROJECT.functions.supabase.co/mono-webhook?secret=YOUR_RANDOM_SECRET
//
// and set the same value with: supabase secrets set MONO_WEBHOOK_SECRET=YOUR_RANDOM_SECRET
// Pick a long random string for this yourself - it's not something Mono
// gives you, it's a shared password only your dashboard and this function
// know, so requests without it get rejected outright.
//
// This deliberately does NOT try to pull and categorize transactions
// itself - it just marks the connection as having new data waiting. The
// actual sync reuses the exact same categorization-rule logic the app's
// CSV import already relies on, which only exists once, tested, on the
// client - not duplicated here.
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const secret = url.searchParams.get("secret");
    if (!secret || secret !== Deno.env.get("MONO_WEBHOOK_SECRET")) {
      return new Response("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const accountId = body?.data?.account?._id || body?.data?.account;
    if (!accountId) return new Response("ok", { status: 200 }); // nothing to act on, but acknowledge receipt

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    await supabase
      .from("bank_connections")
      .update({ needs_sync: true, last_webhook_at: new Date().toISOString() })
      .eq("external_account_id", accountId);

    return new Response("ok", { status: 200 });
  } catch (e) {
    return new Response(String(e?.message || e), { status: 500 });
  }
});
