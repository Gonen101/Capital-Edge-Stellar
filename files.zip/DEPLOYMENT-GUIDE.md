# Deploying CapitalEdge Stellar as a real, multi-tenant website

This turns the single-file artifact into a real hosted app where:
- Anyone can sign up and gets their own brand-new, **completely empty** company
- No one can ever see another company's data (enforced by the database itself)
- **An Admin can invite real teammates to their own company**, each with a role that genuinely controls what they can do
- The first thing anyone sees is the real landing page - animated hero, brand mark, login/signup - not a bare form

## If you already deployed an earlier version of this kit, read this first

This pass adds real multi-user logins with roles. The database structure changed - there's a new `company_members` table that access is now checked against, replacing the old "one owner" model. **You need to re-run the new `supabase/schema.sql` even if you already ran an earlier version.** It's written to be safe to re-run: it won't touch your existing company data, and it includes a one-time step that automatically adds your existing company's owner to the new membership table as Admin - without that step, the new access rules would lock you out of your own company, since it would have zero rows in a table that didn't exist before. Just paste the whole file into the SQL Editor and run it again, the same way as the first time.

## This is a refreshed build, not the original

The app has grown substantially since this kit was first built - Inventory types with their own ledger accounts, Production/usage tracking, Budgets with a lock-until-edit flow, a Subscription panel, Time Sheets, Transaction Locking, Bulk Update, Locations and Departments, Opening Balances, Users & Roles, and dozens of new reports. Everything in this folder was **regenerated from the current app**, not patched forward from the old version:

- `src/App.jsx` - the current app, patched the same three small ways as before (load/save through Supabase instead of browser storage, plus a real sign-out button and a Factory Reset that clears to an empty company instead of ever restoring demo data). Along the way, a real gap was caught and fixed in the source app itself: "Start Fresh" hadn't been updated to clear Sales Orders, Purchase Orders, Time Sheets, Production Records, and several other collections added since it was first written - it does now, in both this hosted copy and the original artifact.
- `src/emptyCompanyData.js` - completely rebuilt against the current chart of accounts (56 accounts now, including the inventory-type accounts, Opening Balance Equity, and the new Users field). **Verified two ways**: every account checked field-by-field against the app's own output, and a full comparison confirming every top-level key in a real company's data has a matching key here, with nothing missing and nothing extra.
- `src/AuthGate.jsx` - the landing page, login/signup, and now the invitation flow, described below.
- `src/supabaseClient.js` - connects to your Supabase project (unchanged).
- `supabase/schema.sql` - the database schema, Row Level Security, the signup trigger, and now real multi-user membership - **re-embedded with the newly-verified empty-company data** - it works as soon as you run it, no editing required.

You do not need to touch any of the business logic. Everything below is account setup, configuration, and deployment - no accounting code to write.

## The landing page

`AuthGate.jsx` now renders the full animated landing page you approved as a standalone preview - the same hero on the left (scattered figures rising into a growth chart, a small figure climbing it book in hand, arriving at a trophy), the CapitalEdge Stellar brand mark, and the same scene running blurred behind the sign-in form on the right. It's the same code, ported directly into a React component rather than rebuilt - what you saw is what ships. The only change: the decorative sign-in box from the preview is replaced with the real, working Supabase auth logic (email/password, signup creates a company via the trigger below, error and loading states).

The wordmark uses Playfair Display, loaded in `index.html`.

---

## 1. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) and create a free account.
2. Click **New Project**. Pick a name, a database password (save it somewhere), and a region close to your users.
3. Wait ~2 minutes for it to provision.

## 2. Run the database schema

1. In your Supabase project, open **SQL Editor** (left sidebar) → **New query**.
2. Open `supabase/schema.sql` from this folder, copy the whole file, paste it in, and click **Run**.
3. You should see "Success. No rows returned." This created two tables (`companies`, `profiles`), turned on Row Level Security, and set up the trigger that gives every new signup their own empty company automatically.

## 3. Get your API keys

1. In Supabase: **Project Settings** (gear icon) → **API**.
2. Copy the **Project URL** and the **anon / public** key. (Not the `service_role` key - that one is a secret and should never go in frontend code.)
3. Just keep these two values somewhere handy for a few minutes - a sticky note, a scratch text file, anything. They go into Vercel's dashboard in step 6, not into any file in this project.

## 4. Configure email confirmation (recommended for a real launch)

By default, Supabase requires users to click a confirmation link before they can log in. For testing, you can turn this off to move faster:

**Authentication** → **Providers** → **Email** → turn off "Confirm email".

Turn it back on before you have real users, or configure a custom SMTP provider (Supabase's docs cover this) so confirmation emails don't land in spam.

## 5. Push to GitHub

You don't need to run anything on your own computer for this - just get the folder onto GitHub.

```bash
git init
git add .
git commit -m "Initial commit"
```

Create a new repository on GitHub, then follow its instructions to push this folder there. (GitHub Desktop, if you prefer a visual tool over the terminal, works just as well for this step.)

## 6. Deploy to Vercel - this is where your two API keys actually go

This is the easiest way to get the two Supabase values into the app - no hidden files, no terminal, just a normal web form.

1. Go to [vercel.com](https://vercel.com), sign in with GitHub, click **Add New → Project**, and pick your repository.
2. Vercel auto-detects Vite - leave the build settings as default.
3. Before clicking Deploy, look for **Environment Variables** on that same page. Add two:
   - Name: `VITE_SUPABASE_URL` — Value: your Project URL from Supabase
   - Name: `VITE_SUPABASE_ANON_KEY` — Value: your anon/public key from Supabase
   - (Optional, only if you're setting up live bank feeds - see that section below) Name: `VITE_MONO_PUBLIC_KEY` — Value: your Mono public key
4. Click **Deploy**.

A few minutes later you have a real URL (`your-project.vercel.app`) with the animated landing page live on it. Every push to your GitHub repo redeploys automatically.

### Using Netlify instead

Nothing here is Vercel-specific - this is a plain Vite build (`npm run build` → a `dist` folder of static files) plus a separate Supabase backend, and Netlify hosts that exactly as well:

1. Go to [netlify.com](https://netlify.com), sign in with GitHub, **Add new site → Import an existing project**, and pick your repository.
2. Netlify auto-detects Vite: build command `npm run build`, publish directory `dist`. Leave both as detected.
3. Before deploying, go to **Site configuration → Environment variables** and add the same two (or three, if using bank feeds) variables listed above, with the exact same `VITE_` prefixed names - Vite only exposes variables to the browser if they start with `VITE_`, on any host.
4. Click **Deploy**.

Everything else in this guide - the Supabase schema, the Edge Functions, the domain step below - works identically regardless of which one you pick, since none of it runs on Vercel or Netlify at all; it's entirely on Supabase's own infrastructure.

## 7. Add a custom domain (optional)

**Vercel Project → Settings → Domains** → add your domain and follow the DNS instructions it gives you. Takes effect within a few minutes to a few hours depending on your DNS provider.

## Multiple organizations under one login

One email can own or belong to more than one organization - separate companies, each with its own completely separate books, its own team, and its own separate subscription. This is the same model Zoho and most real multi-tenant accounting tools use.

**Setup**: run `supabase/schema-multi-org.sql` in the SQL Editor, the same way as the other schema files. It adds one function (`create_organization`) that atomically creates a new, empty organization and makes the calling user its Admin - nothing else about the database changes, since `company_members` already supported one login belonging to several companies without any structural change.

**Using it**: once logged in, the organization name at the top of the sidebar is clickable - it opens a switcher listing every organization you have access to (with your role in each), and an **+ Add organization** option to create a new one on the spot. The new one starts completely empty, exactly like a brand new signup would.

**What's separate per organization, and what isn't**: the books, the team roster, the roles, the subscription/billing, bank feed connections - all of it is fully separate per organization, with its own row in the database, gated by the exact same Row Level Security as everything else (a login only ever sees the organizations it's actually a member of). The only thing shared across organizations is the login itself - one email and password gets you into all of them, switching is instant, and you never need a second account.

## Inviting your team

Once you're signed in as the Admin of a company: **Settings → Users and roles**. Four roles exist - Admin, Accountant, Bookkeeper, Viewer - each described right there in the app.

1. Click **+ Add user**, enter the email address you want to invite and pick their role, then **Create invite**.
2. You'll get a link back. Share it however you'd normally reach them - email, WhatsApp, Slack. It's not sent automatically; there's no backend email service wired up for that yet, so this is a manual step for now.
3. It only works once. When they open it and set a password, they land directly inside your company with the role you picked - they never see the "create a new company" flow, and no new empty company gets created for them.
4. You can change anyone's role, or remove them, from the same screen at any time - both act on the real database immediately, not just this browser.

One safeguard worth knowing: you can't demote or remove the last remaining Admin. If you're the only one, you'd lock yourself out of managing users entirely - the app stops you before that happens.

## Live bank feeds (optional)

The app works completely fine without this - CSV/Excel import already covers bank reconciliation. This is for when you want transactions to arrive automatically instead of exporting a statement by hand. It uses [Mono](https://mono.co), an account-linking API covering 50+ banks across Nigeria, Ghana, Kenya, and South Africa.

**Being upfront about this one specifically**: everything here is built precisely against Mono's current, documented API - but unlike the rest of this kit, I don't have a real Mono account to test the actual linking-a-bank-and-pulling-transactions flow against. The Supabase and build pieces are fully verified the same way as everything else in this kit; this integration is correct-as-documented, not end-to-end tested the way the accounting engine and the auth flow were. Test it against your own Mono sandbox account before relying on it for real transactions, and read the note below about transaction amounts specifically before trusting a single number it brings in.

### Setup

1. **Sign up at [mono.co](https://mono.co)** and create an app in your dashboard to get a **Public key** and **Secret key**.
2. **Run `supabase/schema-bank-feeds.sql`** in the SQL Editor, the same way you ran the main schema - it adds one table (`bank_connections`) for tracking which bank accounts are linked to which company.
3. **Install the Supabase CLI** if you don't have it (`npm install -g supabase`), then from this project folder:
   ```bash
   supabase login
   supabase link --project-ref your-project-ref
   supabase functions deploy mono-exchange
   supabase functions deploy mono-sync
   supabase functions deploy mono-webhook
   ```
4. **Set your secret key** (never as a `VITE_` variable - that would ship it to every browser):
   ```bash
   supabase secrets set MONO_SECRET_KEY=your_real_secret_key
   supabase secrets set MONO_WEBHOOK_SECRET=some_long_random_string_you_make_up
   ```
5. **Add `VITE_MONO_PUBLIC_KEY`** to your Vercel environment variables (step 6 above) - this one's safe to expose client-side, that's what "public key" means.
6. **(Optional) Configure the webhook** in your Mono dashboard: `https://YOUR_PROJECT.functions.supabase.co/mono-webhook?secret=YOUR_MONO_WEBHOOK_SECRET`.

### Using it

Go to Money → Banking - there's now a **Live bank feeds** panel at the top. **Connect a bank account** opens Mono's widget; once linked, pick which of your existing bank accounts (the ones you already set up in this app) it corresponds to, then click **Sync now**. Synced transactions land in exactly the same "uncategorized" queue a CSV import would produce, get auto-categorized against your existing rules the same way, and everything downstream - reconciliation, reporting - works identically regardless of where a transaction came from.

### One thing to verify yourself before trusting the amounts

Some Mono endpoints return amounts in kobo (Nigeria's minor currency unit - 100 kobo = ₦1) and some don't, and this can vary. Rather than guess and risk silently misstating every transaction by 100x, `mono-sync` defaults to treating amounts as already being in the major unit (naira, not kobo). **Make one small test transaction, sync it, and compare the amount that shows up against your bank statement.** If everything comes in exactly 100x too large, open `supabase/functions/mono-sync/index.ts`, change `AMOUNT_DIVISOR` from `1` to `100`, and redeploy that one function (`supabase functions deploy mono-sync`).

## Optional: running it on your own computer first

You don't need this to go live - it's only useful if you want to preview changes before pushing them. If you want to try it:

```bash
npm install
npm run dev
```

This does need a `.env.local` file in the project root with the same two values as above. If creating a file that starts with a dot is giving you trouble (many file managers hide dotfiles by default), skip this step entirely and just use Vercel - it doesn't need this file at all.

---

## What actually rests on the database, versus what's still just the app being polite

Not just app code. In `schema.sql`, every table has Row Level Security turned on, checked against real membership:

```sql
create policy "Members can view their company"
  on companies for select
  using (exists (select 1 from company_members where company_id = companies.id and user_id = auth.uid()));
```

This means even a direct API call using a stolen session token, or a bug in the frontend code, cannot return a company you're not a member of - Postgres itself refuses the query. That part is unambiguous and was true before this update too.

**What's new and also genuinely database-enforced**: a Viewer's login cannot write a change to a company's data, full stop - even if someone bypassed the app entirely and called the Supabase API directly. That's checked in the same way, at the same layer, and doesn't depend on the app's UI cooperating.

**What's still UI-level, honestly**: a Bookkeeper being blocked from Payroll specifically, or from Settings, is enforced by the app hiding and disabling those screens - not by the database refusing to hand over that data in the first place. Because a company's entire dataset is still stored as one JSON object, Postgres can currently only say yes/no to "can this login write to this company at all," not "can this login write to *this specific part* of it." Closing that gap needs the relational rebuild mentioned below - splitting the single JSON blob into real tables, so a Bookkeeper's login could never receive Payroll data in the first place, the same way a Viewer's login now never gets to write anything at all.

## What happens on signup, exactly

1. User fills in the signup form on the landing page → `supabase.auth.signUp()` is called, carrying an invite token in the request if they came from an invite link.
2. Supabase creates the auth user.
3. This fires the `handle_new_user()` trigger (defined in `schema.sql`), which checks for a valid, unused invite token:
   - **No valid token** → creates a new company with the embedded empty-company JSON as its starting `data`, and adds this user to `company_members` as Admin.
   - **Valid token** → adds this user to `company_members` for the *inviting* company, with the role the invitation specified, and marks the invitation used. No new company is created.
4. The user logs in, `AuthGate.jsx` fetches the company they're a real member of (and only that one), works out their actual role from `company_members`, and renders the full app with both.

Nothing in the no-invite path can produce demo data - verified directly: the empty-company JSON was loaded through the app's real `migrateData()` function and confirmed to produce a Balance Sheet of exactly 0 = 0 and a trivially reconciling Cash Flow Statement, with zero invoices, bills, or banks.

## If you make more changes to the app before going further

The same rule as last time: this is a snapshot. If you keep building on the artifact after this, `App.jsx` here won't have those changes until it's re-patched. When you're ready for another release, say so and the same edits (plus a fresh field-by-field verification of `emptyCompanyData.js` against whatever's changed in the chart of accounts) get reapplied to the latest version - not a rebuild from scratch.

## A note on the storage model, honestly

This setup stores each company's entire dataset as one JSON object in a single database column - the same shape the app already used with browser storage, just moved to Postgres. This was the right call to get you live **quickly and with near-zero risk to the tested business logic**, and it's now extended to support real multi-user logins without needing that rebuild first. It has real limitations worth knowing about before you scale: you can't run direct SQL reports across companies, two people editing the *same* company's books at the exact same moment could overwrite each other's changes (last write wins), and - as described above - role restriction below "can write at all" isn't database-enforced yet.

If usage grows past a small team on one set of books, the next real step is splitting this into proper relational tables (one row per transaction, per invoice, etc.), with Row Level Security scoped by both `company_id` and role on each table individually. That's a genuine, separate project - today's multi-user setup doesn't block that migration later, and the roles/permissions UI already built means the *app* side of that work is largely done; what's left at that point is purely the database architecture.

## Known limitations carried over from testing this session

- If you view the Cash Flow Statement for a period that includes the exact date you post an Opening Balance entry, it may show a small reconciliation difference - this is disclosed in the app's own Opening Balances screen. For any period after that date (normal day-to-day use), it reconciles exactly.
- Transaction Locking is wired into the highest-traffic edit/delete points (Journal, Invoices, Bills, Expenses, Inventory adjustments, Production records) but not yet into every single document type in the app (fixed asset disposals and a few older sales/purchase documents aren't gated). Extending it fully is a real, doable follow-up rather than something silently assumed to be complete.
- Invitations are shared manually (you copy a link and send it yourself) rather than emailed automatically - there's no backend email service wired up yet. The link itself is fully functional; only the "an email arrives in their inbox automatically" part is missing.
- Invite links only work for brand new signups right now - if someone already has an account and is invited to a second organization, that invite flow won't attach to their existing login. They'd need to create the additional organization themselves instead (via "+ Add organization"), or accept the invite under a fresh email. Making an invite link work for an already-registered user too is a reasonable next step, just not built yet.
- Live bank feeds (Mono) are built precisely against the documented API, but not end-to-end tested against a real Mono account the way everything else in this session was - verify the amount unit (kobo vs. naira) against your own test transaction before trusting it, as described in that section above.
